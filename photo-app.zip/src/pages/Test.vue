<template>
  <div>
    <uploader />
  </div>
</template>

<script>
import Uploader from '@/components/Uploader'
export default {
  components: {
    Uploader
  }
}
</script>
